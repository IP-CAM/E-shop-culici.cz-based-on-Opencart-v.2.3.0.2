<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Skupina specifikací';
$_['text_success']                                = 'Úspěch: Byly upraveny skupiny specifikací!';
$_['text_list']                                   = 'Seznam skupin specifikací';
$_['text_add']                                    = 'Přidat skupinu specifikací';
$_['text_edit']                                   = 'Upravit skupinu specifikací';
$_['column_name']                                 = 'Název skupiny specifikací';
$_['column_sort_order']                           = 'Pořadí';
$_['column_action']                               = 'Akce';
$_['entry_name']                                  = 'Název skupiny specifikací';
$_['entry_sort_order']                            = 'Pořadí';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat skupiny specifikací!';
$_['error_name']                                  = 'Název skupiny specifikací musí obsahovat 3 až 64 znaky!';
$_['error_attribute']                             = 'Varování: Tato skupina specifikací nemůže být vymazána, protože je přiřazena k %s vlastnostem!';
$_['error_product']                               = 'Varování: Tato skupina specifikací nemůže být vymazána, protože je přiřazena k %s výrobkům!';
