<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Nástěnka';
$_['error_install']                               = 'Upozornění: Instalační adresář stále existuje a z bezpečnostních důvodů by měl být vymazán!';
