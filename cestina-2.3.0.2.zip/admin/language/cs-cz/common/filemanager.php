<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Manažer obrázků';
$_['text_uploaded']                               = 'Úspěch: Soubor byl úspěšně nahrán!';
$_['text_directory']                              = 'Úspěch: Adresář byl vytvořen!';
$_['text_delete']                                 = 'Úspěch: Soubor nebo adresář byl vymazán!';
$_['entry_search']                                = 'Hledat...';
$_['entry_folder']                                = 'Název adresáře';
$_['error_permission']                            = 'Varování: Povolení zamítnuto!';
$_['error_filename']                              = 'Varování: Název souboru musí mít mezi 3 a 255 znaky!';
$_['error_folder']                                = 'Varování: Název adresáře musí mít mezi 3 a 255 znaky!';
$_['error_exists']                                = 'Varování: Soubor nebo adresář s tímto názvem již existuje!';
$_['error_directory']                             = 'Varování: Adresář neexistuje!';
$_['error_filesize']                              = 'Nesprávná velikost souboru!';
$_['error_filetype']                              = 'Varování: Chybný typ souboru!';
$_['error_upload']                                = 'Varování: Soubor nemohl být z neznámých důvodů nahrán!';
$_['error_delete']                                = 'Varování: Tento adresář nelze smazat!';
