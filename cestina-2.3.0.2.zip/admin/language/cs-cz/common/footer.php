<?php //Copyright: opencart.cz
$_['text_footer']                                 = '<a href="http://www.opencart.com">OpenCart</a> &copy; 2009-2016 Všechna práva vyhrazena.<br />Překlad: <a href="http://www.opencart.cz" target="_blank">opencart.cz</a> &amp; <a href="http://www.opencart-support.com" target="_blank">opencart-support.com</a>.';
$_['text_version']                                = 'Verze %s';
