<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Administrace';
$_['text_heading']                                = 'Administrace';
$_['text_login']                                  = 'Zadejte prosím své přihlašovací údaje.';
$_['text_forgotten']                              = 'Zapomenuté heslo';
$_['entry_username']                              = 'Uživatelské jméno';
$_['entry_password']                              = 'Heslo';
$_['button_login']                                = 'Přihlásit se';
$_['error_login']                                 = 'Chybné uživatelské jméno nebo heslo.';
$_['error_token']                                 = 'Relace vypršela. Prosím přihlaste se znovu.';
