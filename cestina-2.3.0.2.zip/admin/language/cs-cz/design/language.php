<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Editor překladu';
$_['text_success']                                = 'Změna překladu proběhla úspěšně!';
$_['text_edit']                                   = 'Změnit překlad';
$_['text_default']                                = 'Default';
$_['text_store']                                  = 'Obchod';
$_['text_language']                               = 'Překlad';
$_['text_translation']                            = 'Zvolte překlad';
$_['entry_key']                                   = 'Klíč';
$_['entry_value']                                 = 'Hodnota';
$_['entry_default']                               = 'Default';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat překlady!';
