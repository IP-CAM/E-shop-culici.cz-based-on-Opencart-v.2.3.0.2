<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Editor vzhledu';
$_['text_success']                                = 'Úspěch: Změna vzhledu proběhla úspěšně!';
$_['text_edit']                                   = 'Upravit vzhled';
$_['text_store']                                  = 'Zvolte obchod';
$_['text_template']                               = 'Zvolte šablonu';
$_['text_default']                                = 'Default';
$_['text_warning']                                = 'Varování: Úpravou vzhledu může být ohrožena bezpečnost Vašeho obchodu!';
$_['text_access']                                 = 'Ujistěte se, že pouze oprávnění admin uživatelé mají přístup na tuto stránku, protože zde se napřímo mění zdrojový kód.';
$_['text_permission']                             = 'Oprávnění uživatele můžete změnit <a href="%s" class="alert-link">zde</a>.';
$_['text_begin']                                  = 'Vyberte soubor šablony z levé části pro zahájení editace.';
$_['error_permission']                            = 'Varování: Nemáte oprávnění na Editor vzhledu!';
