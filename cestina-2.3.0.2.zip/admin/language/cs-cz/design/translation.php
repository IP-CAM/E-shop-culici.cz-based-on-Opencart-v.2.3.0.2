<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Změna překladů';
$_['text_edit']                                   = 'Upravit překlad';
$_['text_list']                                   = 'Seznam překladů';
$_['text_translation']                            = 'Překlady';
$_['column_flag']                                 = 'Vlajka';
$_['column_country']                              = 'Země';
$_['column_progress']                             = 'Průběh překladu';
$_['column_action']                               = 'Akce';
$_['button_install']                              = 'Instalovat';
$_['button_uninstall']                            = 'Odinstalovat';
$_['button_refresh']                              = 'Obnovit';
$_['error_permission']                            = 'Varování: Nemáte oprávnění pro změnu překladů!';
