<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Stránka nenalezena!';
$_['text_not_found']                              = 'Stránka, kterou hledáte, nebyla nalezena! Kontaktujte svého administrátora, pokud problém přetrvává.';
