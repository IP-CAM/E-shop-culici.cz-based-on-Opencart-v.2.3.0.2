<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Povolení zamítnuto!';
$_['text_permission']                             = 'Nemáte povolení navštívit tuto stránku. Obraťte se prosím na svého administrátora.';
