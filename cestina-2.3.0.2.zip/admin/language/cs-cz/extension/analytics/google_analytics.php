<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Google Analytics';
$_['text_extension']                              = 'Rozšíření';
$_['text_success']                                = 'Úspěch: Úspěšně jste upravili Google Analytics!';
$_['text_signup']                                 = 'Přihlásit se na Váš <a href="http://www.google.com/analytics/" target="_blank"><u>Google Analytics</u></a> účet a po vytvoření Vašeho webového profilu zkopírujte a vložte "analytics kód" do tohoto pole.';
$_['text_default']                                = 'Default';
$_['entry_code']                                  = 'Google Analytics Kód';
$_['entry_status']                                = 'Stav';
$_['error_permission']                            = 'Varování: Nemáte oprávnění pro změnu Google Analytics!';
$_['error_code']                                  = 'Kód je povinný!';
