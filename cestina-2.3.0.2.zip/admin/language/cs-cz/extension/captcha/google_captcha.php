<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Google reCAPTCHA';
$_['text_captcha']                                = 'Captcha';
$_['text_success']                                = 'Úspěch: Úspěšně jste upravili Google reCAPTCHA!';
$_['text_edit']                                   = 'upravit Google reCAPTCHA';
$_['text_signup']                                 = 'Přejděte na <a href="https://www.google.com/recaptcha/intro/index.html" target="_blank"><u>Google reCAPTCHA stránku</u></a> a registrujte Váš obchod.';
$_['entry_key']                                   = 'Site key';
$_['entry_secret']                                = 'Secret key';
$_['entry_status']                                = 'Stav';
$_['error_permission']                            = 'Varování: Nemáte oprávnění pro změnu Google reCAPTCHA!';
$_['error_key']                                   = 'Site key - je povinný!';
$_['error_secret']                                = 'Secret - je povinný!';
