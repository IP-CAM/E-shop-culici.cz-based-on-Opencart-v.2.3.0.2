<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Analýza prodeje';
$_['text_extension']                              = 'Rozšíření';
$_['text_success']                                = 'Úspěch: Úspěšně jste upravili graf na nástěnce!';
$_['text_edit']                                   = 'Upravit graf na nástěnce';
$_['text_order']                                  = 'Objednávky';
$_['text_customer']                               = 'Zákazníci';
$_['text_day']                                    = 'Dnes';
$_['text_week']                                   = 'Týden';
$_['text_month']                                  = 'Měsíc';
$_['text_year']                                   = 'Rok';
$_['entry_status']                                = 'Stav';
$_['entry_sort_order']                            = 'Pořadí';
$_['entry_width']                                 = 'Šířka';
$_['error_permission']                            = 'Varování: Nemáte oprávnění editovat "Analýzu prodeje"!';
