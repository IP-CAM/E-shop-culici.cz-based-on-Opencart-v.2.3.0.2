<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Online zákazníci';
$_['text_extension']                              = 'Rozšíření';
$_['text_success']                                = 'Úspěch: Úspěšně jste upravili online modul zákazníků!';
$_['text_edit']                                   = 'Upravit online modul zákazníků';
$_['text_view']                                   = 'Zobrazit více...';
$_['entry_status']                                = 'Stav';
$_['entry_sort_order']                            = 'Pořadí';
$_['entry_width']                                 = 'Šířka';
$_['error_permission']                            = 'Varování: Nemáte oprávnění editovat Online zákazníky!';
