<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Poslední objednávky';
$_['text_extension']                              = 'Rozšíření';
$_['text_success']                                = 'Úspěch: Úspěšně jste upravili poslední objednávky!';
$_['text_edit']                                   = 'Upravit poslední objednávky na nástěnce';
$_['column_order_id']                             = 'Číslo objednávky';
$_['column_customer']                             = 'Zákazník';
$_['column_status']                               = 'Stav';
$_['column_total']                                = 'Celkem';
$_['column_date_added']                           = 'Datum přidání';
$_['column_action']                               = 'Akce';
$_['entry_status']                                = 'Stav';
$_['entry_sort_order']                            = 'Pořadí';
$_['entry_width']                                 = 'Šířka';
$_['error_permission']                            = 'Varování: Nemáte oprávnění editovat poslední objednávky na nástěnce!';
