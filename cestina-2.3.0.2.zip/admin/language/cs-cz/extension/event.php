<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Události';
$_['text_success']                                = 'Úspěch: Úspěšně jste upravili události!';
$_['text_list']                                   = 'Seznam událostí';
$_['text_event']                                  = 'Události použity v rozšířeních mohou blokovat funkčnost Vašeho obchodu. Pokud máte problémy, můžete je zakázat nebo povolit zde.';
$_['column_code']                                 = 'Kód události';
$_['column_trigger']                              = 'Spouštěč';
$_['column_action']                               = 'Akce';
$_['column_status']                               = 'Stav';
$_['column_date_added']                           = 'Datum přidání';
$_['error_permission']                            = 'Varování: Nemáte oprávnění editovat události!';
