<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Rozšíření';
$_['text_success']                                = 'Úspěch: Úspěšně jste upravili rozšíření!';
$_['text_list']                                   = 'Seznam rozšíření';
$_['text_type']                                   = 'Zvolte typ rozšíření';
$_['text_filter']                                 = 'Filtr';
$_['text_analytics']                              = 'Analytics';
$_['text_captcha']                                = 'Captcha';
$_['text_dashboard']                              = 'Nástěnka';
$_['text_feed']                                   = 'Feeds';
$_['text_fraud']                                  = 'Anti-Fraud';
$_['text_module']                                 = 'Moduly';
$_['text_content']                                = 'Obsah modulů';
$_['text_menu']                                   = 'Menu Moduly';
$_['text_payment']                                = 'Platby';
$_['text_shipping']                               = 'Doprav';
$_['text_theme']                                  = 'Šablony';
$_['text_total']                                  = 'Celkem';
