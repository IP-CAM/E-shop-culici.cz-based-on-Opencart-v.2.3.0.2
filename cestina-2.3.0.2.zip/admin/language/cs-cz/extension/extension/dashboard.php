<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Nástěnka';
$_['text_success']                                = 'Úspěch: Úspěšně jste upravili nástěnku!';
$_['text_list']                                   = 'Nástěnka - seznam';
$_['column_name']                                 = 'Název';
$_['column_width']                                = 'Šířka';
$_['column_status']                               = 'Stav';
$_['column_sort_order']                           = 'Pořadí';
$_['column_action']                               = 'Akce';
$_['error_permission']                            = 'Varování: Nemáte oprávnění editovat nástěnku!';
