<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Feeds';
$_['text_success']                                = 'Úspěch: Úspěšně jste upravili feeds!';
$_['text_list']                                   = 'Seznam Feed';
$_['column_name']                                 = 'Název';
$_['column_status']                               = 'Stav';
$_['column_action']                               = 'Akce';
$_['error_permission']                            = 'Varování: Nemáte oprávnění editovat feeds!';
