<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Moduly';
$_['text_success']                                = 'Úspěch: Moduly byly upraveny!';
$_['text_layout']                                 = 'Po instalaci a konfiguraci modulu je jej možno přidat do rozvržení <a href="%s" class="alert-link">zde</a>!';
$_['text_add']                                    = 'Přidat modul';
$_['text_list']                                   = 'Seznam modulů';
$_['column_name']                                 = 'Název modulu';
$_['column_action']                               = 'Akce';
$_['entry_code']                                  = 'Modul';
$_['entry_name']                                  = 'Název modulu';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat moduly!';
$_['error_name']                                  = 'Název modulu musí mít mezi 3 a 64 znaky!';
$_['error_code']                                  = 'Požadováno rozšíření!';
