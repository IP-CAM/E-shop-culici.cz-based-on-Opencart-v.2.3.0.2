<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Platby';
$_['text_success']                                = 'Úspěch: Platby byly upraveny';
$_['text_list']                                   = 'Seznam plateb';
$_['column_name']                                 = 'Způsob platby';
$_['column_status']                               = 'Stav';
$_['column_sort_order']                           = 'Pořadí';
$_['column_action']                               = 'Akce';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat platby!';
