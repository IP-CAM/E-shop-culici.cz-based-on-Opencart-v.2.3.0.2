<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Doprava';
$_['text_success']                                = 'Úspěch: Doprava byla změněna!';
$_['text_list']                                   = 'Seznam dopravy';
$_['column_name']                                 = 'Způsob dopravy';
$_['column_status']                               = 'Stav';
$_['column_sort_order']                           = 'Pořadí';
$_['column_action']                               = 'Akce';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat dopravu.';
