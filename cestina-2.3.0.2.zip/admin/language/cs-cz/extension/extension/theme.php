<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Vzhledy';
$_['text_success']                                = 'Úspěch: Úspěšně jste upravili vzhled!';
$_['text_list']                                   = 'Přehled vzhledů';
$_['column_name']                                 = 'Název vzhledu';
$_['column_status']                               = 'Stav';
$_['column_action']                               = 'Akce';
$_['error_permission']                            = 'Varování: Nemáte oprávnění editovat vzhledy!';
