<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Součty na objednávce';
$_['text_success']                                = 'Úspěch: Součty byly upraveny!';
$_['text_list']                                   = 'Seznam součtů na objednávce';
$_['column_name']                                 = 'Součty na objednávce';
$_['column_status']                               = 'Stav';
$_['column_sort_order']                           = 'Pořadí';
$_['column_action']                               = 'Akce';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat součty na objednávce!';
