<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Google Base';
$_['text_extension']                              = 'Rozšíření';
$_['text_success']                                = 'Úspěch: Úspěšně jste upravili Google Base feed!';
$_['text_edit']                                   = 'Upravit Google Base';
$_['text_import']                                 = 'Pro stažení nejnovějšího seznamu kategorií Google <a href="https://support.google.com/merchants/answer/160081?hl=en" target="_blank" class="alert-link">klikněte zde</a> a zvolte taxonomii s číselnými identifikátory v souboru (jako text) (TXT). Nahrajte pomocí zeleného tlačítka importu';
$_['column_google_category']                      = 'Google kategorie';
$_['column_category']                             = 'Kategorie';
$_['column_action']                               = 'Akce';
$_['entry_google_category']                       = 'Google kategorie';
$_['entry_category']                              = 'Kategorie';
$_['entry_data_feed']                             = 'Data Feed Url';
$_['entry_status']                                = 'Stav';
$_['error_permission']                            = 'Varování: Nemáte oprávnění editovat Google Base feed!';
$_['error_upload']                                = 'Soubor nemohl být nahrán!';
$_['error_filetype']                              = 'Neplatný typ souboru!';
