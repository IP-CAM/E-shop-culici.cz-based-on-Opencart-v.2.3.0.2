<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Google Sitemap';
$_['text_extension']                              = 'Rozšíření';
$_['text_success']                                = 'Úspšch: Úspěšně jste upravili Google Sitemap feed!';
$_['text_edit']                                   = 'Upravit Google Sitemap';
$_['entry_status']                                = 'Stav';
$_['entry_data_feed']                             = 'Data Feed Url';
$_['error_permission']                            = 'Varování: Nemáte oprávnění editovat Google Sitemap feed!';
