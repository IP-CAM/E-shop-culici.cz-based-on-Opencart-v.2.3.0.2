<?php //Copyright: opencart.cz
$_['heading_title']                               = 'OpenBay Pro';
$_['text_module']                                 = 'Moduly';
$_['text_installed']                              = 'OpenBay Pro modul je nyní nainstalován. Je dostupný v Rozšíření -> OpenBay Pro';
