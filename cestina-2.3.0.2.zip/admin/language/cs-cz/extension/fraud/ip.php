<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Anti-Fraud IP';
$_['text_extension']                              = 'Rozšíření';
$_['text_success']                                = 'Úspěch: Úspěšně jste upravili Anti-Fraud IP!';
$_['text_edit']                                   = 'Upravit Anti-Fraud IP';
$_['text_ip_add']                                 = 'Přidat IP adresu';
$_['text_ip_list']                                = 'Fraud IP Address seznam';
$_['column_ip']                                   = 'IP';
$_['column_total']                                = 'Celkový počet účtů';
$_['column_date_added']                           = 'Datum přidání';
$_['column_action']                               = 'Akce';
$_['entry_ip']                                    = 'IP';
$_['entry_status']                                = 'Stav';
$_['entry_order_status']                          = 'Stav objednávky';
$_['help_order_status']                           = 'Zákazníci, kteří mají zabanovanou IP adresu, budou mít stav objednávky "nepovolen", aby nedosáhli stavu objednávky "dokončeno" automaticky.';
$_['error_permission']                            = 'Varování: Nemáte oprávnění pro editaci Anti-Fraud IP!';
