<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Účet';
$_['text_extension']                              = 'Rozšíření';
$_['text_success']                                = 'Úspěšně jste upravili modul účtu!';
$_['text_edit']                                   = 'Updariv modul účtu';
$_['entry_status']                                = 'Stav';
$_['error_permission']                            = 'Varování: Nemáte oprávnění pro edutaci modulu účtu!';
