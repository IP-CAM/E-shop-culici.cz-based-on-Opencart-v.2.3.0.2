<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Partner';
$_['text_extension']                              = 'Rozšíření';
$_['text_success']                                = 'Úspěch: Byl upraven modul Partner!';
$_['text_edit']                                   = 'Upravit modul Partner';
$_['entry_status']                                = 'Stav';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat modul Partner!';
