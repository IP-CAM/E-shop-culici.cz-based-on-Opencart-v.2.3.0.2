<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Banner';
$_['text_extension']                              = 'Rozšíření';
$_['text_success']                                = 'Úspěch: Byl upraven modul Banner!';
$_['text_edit']                                   = 'Upravit modul Banner';
$_['entry_name']                                  = 'Název modulu';
$_['entry_banner']                                = 'Banner';
$_['entry_dimension']                             = 'Rozměry (šířka x výška) and typ změny velikosti';
$_['entry_width']                                 = 'Šířka';
$_['entry_height']                                = 'Výška';
$_['entry_status']                                = 'Stav';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat modul Banner!';
$_['error_name']                                  = 'Název modulu musí mít mezi 3 a 64 znaky!';
$_['error_width']                                 = 'Požadována šířka!';
$_['error_height']                                = 'Požadována výška!';
