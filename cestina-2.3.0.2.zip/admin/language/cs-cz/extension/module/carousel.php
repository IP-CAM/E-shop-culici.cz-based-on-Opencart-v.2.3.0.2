<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Pás obrázků';
$_['text_extension']                              = 'Rozšíření';
$_['text_success']                                = 'Úspěch: Byl upraven modul Pás obrázků!';
$_['text_edit']                                   = 'Upravit modul Pás obrázků';
$_['entry_name']                                  = 'Název modulu';
$_['entry_banner']                                = 'Baner';
$_['entry_width']                                 = 'Šířka';
$_['entry_height']                                = 'Výška';
$_['entry_status']                                = 'Stav';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat modul Pás obrázků!';
$_['error_name']                                  = 'Název modulu musí mít mezi 3 a 64 znaky!';
$_['error_width']                                 = 'Požadována šířka!';
$_['error_height']                                = 'Požadována výška!';
