<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Kategorie';
$_['text_extension']                              = 'Rozšíření';
$_['text_success']                                = 'Úspěch: Byl upraven modul Kategorie!';
$_['text_edit']                                   = 'Upravit modul Kategorie';
$_['entry_status']                                = 'Stav';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat modul Kategorie!';
