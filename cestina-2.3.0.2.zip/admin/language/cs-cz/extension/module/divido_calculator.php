<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Kalkulátor produkt stránky Divido';
$_['text_extension']                              = 'Rozšíření';
$_['text_success']                                = 'Úspěch: Úspěšně jste upravili Kalkulátor produkt stránky Divido!';
$_['text_edit']                                   = 'Upravit kalkulátor produkt stránky Divido';
$_['entry_status']                                = 'Stav';
$_['error_permission']                            = 'Varování: Nemáte oprávnění editace kalkulátoru produkt stránky Divido!';
