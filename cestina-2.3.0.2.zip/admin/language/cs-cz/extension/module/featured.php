<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Doporučené produkty';
$_['text_extension']                              = 'Rozšíření';
$_['text_success']                                = 'Úspěch: Byl upraven modul Doporučené produkty!';
$_['text_edit']                                   = 'Upravit modul Doporučené produkty';
$_['entry_name']                                  = 'Název modulu';
$_['entry_product']                               = 'Výrobky';
$_['entry_limit']                                 = 'Limit';
$_['entry_width']                                 = 'Šířka';
$_['entry_height']                                = 'Výška';
$_['entry_status']                                = 'Stav';
$_['help_product']                                = '(automatické dokončení)';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat modul Doporučené produkty!';
$_['error_name']                                  = 'Název modulu musí mít mezi 3 a 64 znaky!';
$_['error_width']                                 = 'Požadována šířka!';
$_['error_height']                                = 'Požadována výška!';
