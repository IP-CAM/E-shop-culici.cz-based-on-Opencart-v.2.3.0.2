<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Filtr';
$_['text_extension']                              = 'Rozšíření';
$_['text_success']                                = 'Úspěch: Byl upraven modul Filtr!';
$_['text_edit']                                   = 'Upravit modul Filtr';
$_['entry_status']                                = 'Stav';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat modul Filtr!';
