<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Google Hangouts';
$_['text_extension']                              = 'Rozšíření';
$_['text_success']                                = 'Úspěch: Úspěšně jste upravili modul Google Hangouts!';
$_['text_edit']                                   = 'Upravit modul Google Hangouts';
$_['entry_code']                                  = 'Google Talk kód';
$_['entry_status']                                = 'Stav';
$_['help_code']                                   = 'Přejděte na <a href="https://developers.google.com/+/hangouts/button" target="_blank">Vytvořit Google Hangout chatback badge</a> zkopírujte &amp; vložte vygenerovaný kód.';
$_['error_permission']                            = 'Varování: Nemáte oprávnění pro změnu Google Hangouts modulu!';
$_['error_code']                                  = 'Kód je povinný';
