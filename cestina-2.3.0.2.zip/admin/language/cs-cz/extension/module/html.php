<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Obsah HTML';
$_['text_extension']                              = 'Rozšíření';
$_['text_success']                                = 'Úspěch: Byl upraven modul Obsah HTML!';
$_['text_edit']                                   = 'Upravit modul Obsah HTML';
$_['entry_name']                                  = 'Název modulu';
$_['entry_title']                                 = 'Nadpis';
$_['entry_description']                           = 'Popis';
$_['entry_status']                                = 'Stav';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat modul Obsah HTML!';
$_['error_name']                                  = 'Název modulu musí mít mezi 3 a 64 znaky!';
