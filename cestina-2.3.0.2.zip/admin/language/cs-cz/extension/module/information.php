<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Informace';
$_['text_extension']                              = 'Rozšíření';
$_['text_success']                                = 'Úspěch: Byl upraven modul Informace!';
$_['text_edit']                                   = 'Upravit modul Informace';
$_['entry_status']                                = 'Stav';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat modul Informace!';
