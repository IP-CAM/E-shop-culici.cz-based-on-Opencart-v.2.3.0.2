<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Lay-Buy Rozložení';
$_['text_extension']                              = 'Rozšíření';
$_['text_success']                                = 'Úspěch: Úspěšně jste upravili Lay-Buy rozložení!';
$_['text_edit']                                   = 'Upravit modul Lay-Buy rozložení';
$_['entry_status']                                = 'Stav';
$_['error_permission']                            = 'Varování: Nemáte oprávnení pro editaci Lay-Buy rozložení!';
