<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Pilibaba tlačítko pokladny';
$_['text_extension']                              = 'Rozšíření';
$_['text_success']                                = 'Úspěch: Úspěšně jste upravili Pilibaba tlačítko pokladny!';
$_['text_edit']                                   = 'Upravit Pilibaba tlačítko pokladny';
$_['entry_status']                                = 'Stav';
$_['error_permission']                            = 'Varování: Nemáte oprávnění pro editaci Pilibaba tlačítka pokladny!';
