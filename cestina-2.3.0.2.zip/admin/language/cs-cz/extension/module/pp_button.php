<?php //Copyright: opencart.cz
$_['heading_title']                               = 'PayPal Express Checkout Button';
$_['text_extension']                              = 'Rozšíření';
$_['text_success']                                = 'Úspěch: Úspěšně jste upravili PayPal Express Checkout Button modul!';
$_['text_edit']                                   = 'Upravit modul PayPal Express Checkout Button';
$_['entry_status']                                = 'Stav';
$_['error_permission']                            = 'Varování: Nemáte oprávnění měnit PayPal Express Checkout Button modul!';
