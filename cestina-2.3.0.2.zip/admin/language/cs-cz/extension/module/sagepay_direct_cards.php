<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Sagepay Direct Card Management';
$_['text_extension']                              = 'Rozšíření';
$_['text_success']                                = 'Úspěch: Úspěšně jste upravili Sagepay Direct Card Management!';
$_['text_edit']                                   = 'Upravit Sagepay Direct Card Management';
$_['entry_status']                                = 'Stav';
$_['error_permission']                            = 'Varování: Nemáte oprávnění pro editaci Sagepay Direct Card Management!';
