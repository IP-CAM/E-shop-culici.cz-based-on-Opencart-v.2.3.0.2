<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Sagepay Server Card Management';
$_['text_extension']                              = 'Rozšíření';
$_['text_success']                                = 'Úspěch: Úspěšně jste upravili Sagepay Server Card Management!';
$_['text_edit']                                   = 'Upravit Sagepay Server Card Management';
$_['entry_status']                                = 'Stav';
$_['error_permission']                            = 'Varování: Nemáte oprávnění pro editaci Sagepay Server Card Management!';
