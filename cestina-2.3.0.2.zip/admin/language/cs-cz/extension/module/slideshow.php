<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Nastavení zobrazení bannerů (Slideshow)';
$_['text_extension']                              = 'Rozšíření';
$_['text_success']                                = 'Úspěch: Byl upraven modul Slideshow!';
$_['text_edit']                                   = 'Upravit modul Slideshow';
$_['entry_name']                                  = 'Název modulu';
$_['entry_banner']                                = 'Baner';
$_['entry_width']                                 = 'Šířka';
$_['entry_height']                                = 'Výška';
$_['entry_status']                                = 'Stav';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat modul Slideshow!';
$_['error_name']                                  = 'Název modulu musí mít mezi 3 a 64 znaky!';
$_['error_width']                                 = 'Požadována šířka!';
$_['error_height']                                = 'Požadována výška!';
