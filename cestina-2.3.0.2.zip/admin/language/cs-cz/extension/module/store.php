<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Obchod';
$_['text_extension']                              = 'Rozšíření';
$_['text_success']                                = 'Úspěch: Byl upraven modul Obchod!';
$_['text_edit']                                   = 'Upravit modul Obchod';
$_['entry_admin']                                 = 'Pouze administrátoři';
$_['entry_status']                                = 'Stav';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat modul Obchod!';
