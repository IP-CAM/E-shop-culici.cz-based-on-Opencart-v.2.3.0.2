<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Amazon EU';
$_['text_openbay']                                = 'OpenBay Pro';
$_['text_dashboard']                              = 'Amazon EU Nástěnka';
$_['text_heading_settings']                       = 'nastavení';
$_['text_heading_account']                        = 'Změnit plán';
$_['text_heading_links']                          = 'Odkazy položek';
$_['text_heading_register']                       = 'Registrovat';
$_['text_heading_bulk_listing']                   = 'Hromadný výpis';
$_['text_heading_stock_updates']                  = 'Aktualizace skladu';
$_['text_heading_saved_listings']                 = 'Uložené výpisy';
$_['text_heading_bulk_linking']                   = 'Hromadné odkazování';
