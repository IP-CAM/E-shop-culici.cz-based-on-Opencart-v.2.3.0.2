<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Fulfillments';
$_['text_openbay']                                = 'OpenBay Pro';
$_['text_fba']                                    = 'Fulfillment By Amazon';
$_['entry_start_date']                            = 'Start date (format YYYY-MM-DD)';
$_['text_no_results']                             = 'No fulfillment\'s found on Amazon';
$_['text_fulfillment_list']                       = 'Amazon Fulfillment list';
$_['column_seller_fulfillment_order_id']          = 'Seller Order ID';
$_['column_displayable_order_id']                 = 'Displayable Order ID';
$_['column_displayable_order_date']               = 'Displayable date/time';
$_['column_shipping_speed_category']              = 'Shipping speed';
$_['column_fulfillment_order_status']             = 'Order Status';
$_['column_action']                               = 'Action';
