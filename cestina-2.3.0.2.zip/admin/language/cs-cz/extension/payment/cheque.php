<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Šek';
$_['text_extension']                              = 'Rozšíření';
$_['text_success']                                = 'Úspěch: Byl upraven podrobnosti o šeku!';
$_['text_edit']                                   = 'Upravit Šek';
$_['entry_payable']                               = 'Splatné (komu)';
$_['entry_total']                                 = 'Celkem';
$_['entry_order_status']                          = 'Stav objednávky';
$_['entry_geo_zone']                              = 'Daňová oblast';
$_['entry_status']                                = 'Stav';
$_['entry_sort_order']                            = 'Pořadí';
$_['help_total']                                  = 'Celková hodnota objednávky musí dosáhnout této sumy, aby se použil tento způsob platby.';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat Šek!';
$_['error_payable']                               = 'Vyplňte Splatné (komu)!';
