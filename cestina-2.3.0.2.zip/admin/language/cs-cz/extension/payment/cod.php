<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Dobírka';
$_['text_extension']                              = 'Rozšíření';
$_['text_success']                                = 'Úspěch: Byl upraven modul Dobírka!';
$_['text_edit']                                   = 'Upravit modul Dobírka';
$_['entry_total']                                 = 'Celkem';
$_['entry_order_status']                          = 'Stav objednávky';
$_['entry_geo_zone']                              = 'Daňová oblast';
$_['entry_status']                                = 'Stav';
$_['entry_sort_order']                            = 'Pořadí';
$_['help_total']                                  = 'Výše nákupu, která musí být dosažena před tím, než se tento způsob platby stane aktivním.';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat platbu Dobírka!';
