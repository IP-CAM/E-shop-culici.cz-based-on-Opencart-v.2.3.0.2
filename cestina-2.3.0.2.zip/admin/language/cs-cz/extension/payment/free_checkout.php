<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Objednávka zdarma';
$_['text_extension']                              = 'Rozšíření';
$_['text_success']                                = 'Úspěch: Byl upraven modul Objednávka zdarma!';
$_['text_edit']                                   = 'Upravit modul Objednávka zdarma';
$_['entry_order_status']                          = 'Stav objednávky';
$_['entry_status']                                = 'Stav';
$_['entry_sort_order']                            = 'Pořadí';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat modul Objednávka zdarma!';
