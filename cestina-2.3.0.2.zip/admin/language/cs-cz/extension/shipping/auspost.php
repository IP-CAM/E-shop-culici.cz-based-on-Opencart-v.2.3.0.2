<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Australia Post';
$_['text_shipping']                               = 'Doprava';
$_['text_success']                                = 'Úspěch: Úspěšně jste upravili dopravu Australia Post!';
$_['text_edit']                                   = 'Upravit dopravu Australia Post';
$_['entry_postcode']                              = 'PSČ';
$_['entry_express']                               = 'Express Postage';
$_['entry_standard']                              = 'Standard Postage';
$_['entry_display_time']                          = 'Zobrazit čas doručení';
$_['entry_weight_class']                          = 'Váhová třída';
$_['entry_tax_class']                             = 'Daňová DPH';
$_['entry_geo_zone']                              = 'Daňová oblast';
$_['entry_status']                                = 'Stav';
$_['entry_sort_order']                            = 'Pořadí';
$_['help_display_time']                           = 'Chcete zobrazit čas přepravy? (například dodávka do 3 až 5 dnů)';
$_['help_weight_class']                           = 'Nastavit na gramy.';
$_['error_permission']                            = 'Varování: Nemáte oprávnění měnit Australia Post dopravu!';
$_['error_postcode']                              = 'PSČ musí mít 4 znaky!';
