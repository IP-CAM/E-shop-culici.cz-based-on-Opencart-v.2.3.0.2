<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Citylink';
$_['text_shipping']                               = 'Doprava';
$_['text_success']                                = 'Úspěch: Úspěšně jste upravili Citylink dopravu!';
$_['text_edit']                                   = 'Upravit dopravu Citylink';
$_['entry_rate']                                  = 'Citylink ceny';
$_['entry_tax_class']                             = 'Daňová třída';
$_['entry_geo_zone']                              = 'Daňová oblast';
$_['entry_status']                                = 'Stav';
$_['entry_sort_order']                            = 'Pořadí';
$_['help_rate']                                   = 'Zadejte hodnoty na 5,2 desetinných míst. (12345,67) Příklad: 0,1: 1, 0,25: 1,27 - Váží méně než nebo roveno 0,1 kg astojí libru, 1.00, bude hmotnosti menší nebo rovna 0,25 g, ale více než 0,1 kg stojí 1,27. Nezadávejte kg nebo symboly.';
$_['error_permission']                            = 'Varování: Nemáte oprávnění menit Citylink dopravu!';
