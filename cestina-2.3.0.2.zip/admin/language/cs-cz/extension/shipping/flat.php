<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Jednotná sazba dopravy';
$_['text_shipping']                               = 'Doprava';
$_['text_success']                                = 'Úspěch: Byla upravena jednotná sazba dopravy!';
$_['text_edit']                                   = 'Upravit jednotnou sazbu dopravy';
$_['entry_cost']                                  = 'Cena';
$_['entry_tax_class']                             = 'Daňová třída';
$_['entry_geo_zone']                              = 'Daňová oblast';
$_['entry_status']                                = 'Stav';
$_['entry_sort_order']                            = 'Pořadí';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat jednotnou sazbu dopravy!';
