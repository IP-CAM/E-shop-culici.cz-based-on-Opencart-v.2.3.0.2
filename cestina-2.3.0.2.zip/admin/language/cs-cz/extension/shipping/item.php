<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Doprava za kus';
$_['text_shipping']                               = 'Doprava';
$_['text_success']                                = 'Úspěch: Byl upravena doprava za kus!';
$_['text_edit']                                   = 'Upravit dopravu za kus';
$_['entry_cost']                                  = 'Cena';
$_['entry_tax_class']                             = 'Daňová třída';
$_['entry_geo_zone']                              = 'Daňová oblast';
$_['entry_status']                                = 'Stav';
$_['entry_sort_order']                            = 'Pořadí';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat dopravu za kus!';
