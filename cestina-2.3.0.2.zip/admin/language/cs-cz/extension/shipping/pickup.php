<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Vyzvednutí v obchodě';
$_['text_shipping']                               = 'Doprava';
$_['text_success']                                = 'Úspěch: Byl upraveno Vyzvednutí v obchodě!';
$_['text_edit']                                   = 'Upravit Vyzvednutí v obchodě';
$_['entry_geo_zone']                              = 'Daňová oblast';
$_['entry_status']                                = 'Stav';
$_['entry_sort_order']                            = 'Pořadí';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat Vyzvednutí v obchodě!';
