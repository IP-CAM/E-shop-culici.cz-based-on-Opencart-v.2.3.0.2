<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Doprava založená na váze';
$_['text_shipping']                               = 'Doprava';
$_['text_success']                                = 'Úspěch: Byla upravena Doprava založená na váze!';
$_['text_edit']                                   = 'Upravit dopravu založená na váze';
$_['entry_rate']                                  = 'Ceny';
$_['entry_tax_class']                             = 'Daňová třída';
$_['entry_geo_zone']                              = 'Daňová oblast';
$_['entry_status']                                = 'Stav';
$_['entry_sort_order']                            = 'Pořadí';
$_['help_rate']                                   = 'Příklad: 5:10.00,7:12.00 Weight:Cost,Weight:Cost, etc..';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat weight based shipping!';
