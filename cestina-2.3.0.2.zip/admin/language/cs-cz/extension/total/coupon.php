<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Kupón';
$_['text_total']                                  = 'Součty na objednávce';
$_['text_success']                                = 'Úspěch: Byl upraven součet kupónu!';
$_['text_edit']                                   = 'Upravit kupón';
$_['entry_status']                                = 'Stav';
$_['entry_sort_order']                            = 'Pořadí';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat součet kupónu!';
