<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Úvěr obchodu';
$_['text_total']                                  = 'Součty na objednávce';
$_['text_success']                                = 'Úspěch: Byl upraven součet úvěru poskytovaného obchodem!';
$_['text_edit']                                   = 'Upravit součet úvěru poskytovaného obchodem';
$_['entry_status']                                = 'Stav';
$_['entry_sort_order']                            = 'Pořadí';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat úvěru poskytovaného obchodem!';
