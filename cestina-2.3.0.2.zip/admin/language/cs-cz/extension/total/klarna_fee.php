<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Klarna Fee';
$_['text_total']                                  = 'Součty na objednávce';
$_['text_success']                                = 'Úspěch: Byl upraven Klarna fee!';
$_['text_edit']                                   = 'Upravit Klarna Fee';
$_['text_sweden']                                 = 'Švédsko';
$_['text_norway']                                 = 'Norsko';
$_['text_finland']                                = 'Finsko';
$_['text_denmark']                                = 'Dánsko';
$_['text_germany']                                = 'Německo';
$_['text_netherlands']                            = 'Nizozemí';
$_['entry_total']                                 = 'Součet na objednávce';
$_['entry_fee']                                   = 'Poplatek';
$_['entry_tax_class']                             = 'Daňová třída';
$_['entry_status']                                = 'Stav';
$_['entry_sort_order']                            = 'Pořadí';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat součet Klarna fee!';
