<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Low Order Fee';
$_['text_total']                                  = 'Součty na objednávce';
$_['text_success']                                = 'Úspěch: Úspěšně jste upravili Low Order Fee!';
$_['text_edit']                                   = 'Upravit Low Order Fee';
$_['entry_total']                                 = 'Součty na objednávce';
$_['entry_fee']                                   = 'Poplatek';
$_['entry_tax_class']                             = 'Daňová třída';
$_['entry_status']                                = 'Stav';
$_['entry_sort_order']                            = 'Pořadí';
$_['help_total']                                  = 'Souček objednávky musí být větší než tato hodnota.';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat součet Low Order Fee!';
