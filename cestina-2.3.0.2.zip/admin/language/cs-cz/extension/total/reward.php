<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Bonusové body';
$_['text_total']                                  = 'Součty na objednávce';
$_['text_success']                                = 'Úspěch: Byl upraven součet bonusových bodů!';
$_['text_edit']                                   = 'Upravit součet bonusových bodů';
$_['entry_status']                                = 'Stav';
$_['entry_sort_order']                            = 'Pořadí';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat součet bonusových bodů!';
