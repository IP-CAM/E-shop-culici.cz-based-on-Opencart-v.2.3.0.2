<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Mezisoučet';
$_['text_total']                                  = 'Součty na objednávce';
$_['text_success']                                = 'Úspěch: Byl upraven mezisoučet!';
$_['text_edit']                                   = 'Upravit mezisoučet';
$_['entry_status']                                = 'Stav';
$_['entry_sort_order']                            = 'Pořadí';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat mezisoučet!';
