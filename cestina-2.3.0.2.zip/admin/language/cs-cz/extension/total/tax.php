<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Daně';
$_['text_total']                                  = 'Součty na objednávce';
$_['text_success']                                = 'Úspěch: Byly upraveny součty daní!';
$_['text_edit']                                   = 'Upravit součet daně';
$_['entry_status']                                = 'Stav';
$_['entry_sort_order']                            = 'Pořadí';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat součet daně!';
