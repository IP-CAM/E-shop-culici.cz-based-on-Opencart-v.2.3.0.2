<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Celkem';
$_['text_total']                                  = 'Součty na objednávce';
$_['text_success']                                = 'Úspěch: Byl upraven součet celkem!';
$_['text_edit']                                   = 'Upravit součet celkem';
$_['entry_status']                                = 'Stav';
$_['entry_sort_order']                            = 'Pořadí';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat součet celkem!';
