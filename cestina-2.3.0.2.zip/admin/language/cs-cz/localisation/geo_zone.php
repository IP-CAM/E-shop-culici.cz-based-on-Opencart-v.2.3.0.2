<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Daňové oblasti';
$_['text_success']                                = 'Úspěch: Daňové oblasti byly upraveny;!';
$_['text_list']                                   = 'Seznam daňových oblastí';
$_['text_add']                                    = 'Přidat daňovou oblast';
$_['text_edit']                                   = 'Upravit daňovou oblast';
$_['column_name']                                 = 'Název daňové oblasti';
$_['column_description']                          = 'Popis';
$_['column_action']                               = 'Akce';
$_['entry_name']                                  = 'Název daňové oblasti';
$_['entry_description']                           = 'Popis';
$_['entry_country']                               = 'Země';
$_['entry_zone']                                  = 'Oblast';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat daňové oblasti!';
$_['error_name']                                  = 'Název daňové oblasti musí obsahovat 3 až 32 znaky!';
$_['error_description']                           = 'Popis musí obsahovat 3 až 255 znaků!';
$_['error_tax_rate']                              = 'Varování: Tato daňová oblast nemůže být vymazána, protože je přiřazena k minimálně jedné daňové sazbě!';
