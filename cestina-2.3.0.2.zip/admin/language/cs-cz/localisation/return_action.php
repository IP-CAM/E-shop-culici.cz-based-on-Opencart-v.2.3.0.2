<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Reklamace - akce';
$_['text_success']                                = 'Úspěch: Reklamace - akce byly upraveny!';
$_['text_list']                                   = 'Seznam akcí reklamace';
$_['text_add']                                    = 'Přidat akci reklamace';
$_['text_edit']                                   = 'Upravit akci reklamace';
$_['column_name']                                 = 'Zázev akce reklamace';
$_['column_action']                               = 'Akce';
$_['entry_name']                                  = 'Název akce reklamace';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat reklamace - akce!';
$_['error_name']                                  = 'Název akce reklamace musí obsahovat 3 až 64 znaky!';
$_['error_return']                                = 'Varování: Tato akce reklamace nemůže být vymazána, protože je přiřazena k %s reklamovaným produktům!';
