<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Důvody reklamace';
$_['text_success']                                = 'Úspěch: Byly upraveny důvody reklamace!';
$_['text_list']                                   = 'Seznam důvodů reklamace';
$_['text_add']                                    = 'Přidat důvod reklamace';
$_['text_edit']                                   = 'Upravit důvod reklamace';
$_['column_name']                                 = 'Název důvodu reklamace;';
$_['column_action']                               = 'Akce';
$_['entry_name']                                  = 'Název důvodu reklamace';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat důvody reklamací!';
$_['error_name']                                  = 'Název důvodu reklamace musí obsahovat 3 až 128 znaků!';
$_['error_return']                                = 'Varování: Tento důvod reklamace nemůže být vymazán, protože je přiřazen to %s reklamovaným produktům!';
