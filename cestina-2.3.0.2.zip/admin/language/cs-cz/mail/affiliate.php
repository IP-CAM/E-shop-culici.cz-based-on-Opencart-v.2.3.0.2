<?php //Copyright: opencart.cz
$_['text_approve_subject']                        = '%s - Váš členský účet byl aktivován!';
$_['text_approve_welcome']                        = 'Vítejte! Děkujeme za registraci v našem obchodě %s!';
$_['text_approve_login']                          = 'Váš účet byl vytvořen. Můžete se přihlásit pomocí Vaší e-mailové adresy a hesla, nebo na následující URL:';
$_['text_approve_services']                       = 'Po přihlášení na účet budete moci vygenerovat Váš sledovací kód, sledovat Vaši provizi a upravovat informace o Vašem účtu.';
$_['text_approve_thanks']                         = 'Děkujeme,';
$_['text_transaction_subject']                    = '%s - Členská provize';
$_['text_transaction_received']                   = 'Přijali jste provizi v hodnotě %s!';
$_['text_transaction_total']                      = 'Vaše celková výše provizí je nyní %s.';
