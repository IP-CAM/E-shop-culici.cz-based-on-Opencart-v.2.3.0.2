<?php //Copyright: opencart.cz
$_['text_subject']                                = '%s - Obnovení hesla';
$_['text_greeting']                               = 'Nové heslo je požadováno pro správu obchodu %s.';
$_['text_change']                                 = 'K obnovení hesla klikněte na následující odkaz:';
$_['text_ip']                                     = 'Požadavek byl uskutečněn z IP adresy: %s';
