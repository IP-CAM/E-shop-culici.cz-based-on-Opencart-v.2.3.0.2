<?php //Copyright: opencart.cz
$_['text_subject']                                = '%s - Změna stavu reklamace zboží %s';
$_['text_return_id']                              = 'Číslo reklamace:';
$_['text_date_added']                             = 'Datum reklamace:';
$_['text_return_status']                          = 'Status Vaší reklamace byl změněn na:';
$_['text_comment']                                = 'Důvody pro Vaši reklamaci jsou:';
$_['text_footer']                                 = 'Případné dotazy zašlete na tento e-mail.';
