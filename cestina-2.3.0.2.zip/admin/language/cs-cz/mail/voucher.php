<?php //Copyright: opencart.cz
$_['text_subject']                                = 'Byl Vám zaslán dárkový pouzak od %s';
$_['text_greeting']                               = 'Gratulujeme, obdržel(a) jste dárkový poukaz v hodnotě %s';
$_['text_from']                                   = 'Tento dárkový poukaz Vám byl zaslán od %s';
$_['text_message']                                = 'Se zprávou:';
$_['text_redeem']                                 = 'Pro použití tohoto dárkového poukazu si poznamenejte následující kód <b>%s</b>, potom klikněte na odkaz níže a vyberte si zboží, na které chcete uplatnit Váž dárkový poukaz. Vložte svůj kód na stránce Nákupní košík před tím než stisknete Checkout.';
$_['text_footer']                                 = 'Please reply to this email if you have any questions.';
