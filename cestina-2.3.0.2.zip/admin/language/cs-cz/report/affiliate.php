<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Hlášení - Partnerská provize';
$_['text_list']                                   = 'Partnerská provize - Seznam';
$_['column_affiliate']                            = 'Název obchodního partnera';
$_['column_email']                                = 'E-mail';
$_['column_status']                               = 'Stav';
$_['column_commission']                           = 'Provize';
$_['column_orders']                               = 'Počet objednávek';
$_['column_total']                                = 'Celkem';
$_['column_action']                               = 'Akce';
$_['entry_date_start']                            = 'Datum - od:';
$_['entry_date_end']                              = 'Datum - do:';
