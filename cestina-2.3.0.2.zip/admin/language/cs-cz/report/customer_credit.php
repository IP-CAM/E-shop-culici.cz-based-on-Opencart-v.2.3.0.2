<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Hlášení o kreditu zákazníka';
$_['text_list']                                   = 'Seznam kreditů zákazníka';
$_['column_customer']                             = 'Jméno zákazníka';
$_['column_email']                                = 'E-mail';
$_['column_customer_group']                       = 'Skupina zákazníků';
$_['column_status']                               = 'Stav';
$_['column_total']                                = 'Celkem';
$_['column_action']                               = 'Akce';
$_['entry_date_start']                            = 'Datum - od:';
$_['entry_date_end']                              = 'Datum - do:';
$_['entry_customer']                              = 'Zákazník';
