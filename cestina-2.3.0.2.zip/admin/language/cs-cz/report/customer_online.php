<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Hlášení o zákaznících online';
$_['text_list']                                   = 'Seznam zákazníků online';
$_['text_guest']                                  = 'Host';
$_['column_ip']                                   = 'IP';
$_['column_customer']                             = 'Zákazník';
$_['column_url']                                  = 'Poslední navštívená stránka';
$_['column_referer']                              = 'Zákazníka doporučil:';
$_['column_date_added']                           = 'Poslední klik';
$_['column_action']                               = 'Akce';
$_['entry_ip']                                    = 'IP';
$_['entry_customer']                              = 'Zákazník';
