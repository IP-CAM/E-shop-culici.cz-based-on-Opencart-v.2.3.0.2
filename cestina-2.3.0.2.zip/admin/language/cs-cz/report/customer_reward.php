<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Hlášení o bonusových bodech zákazníka';
$_['text_list']                                   = 'Seznam bonusových bodů zákazníka';
$_['column_customer']                             = 'Jméno zákazníka';
$_['column_email']                                = 'E-mail';
$_['column_customer_group']                       = 'Skupina zákazníků';
$_['column_status']                               = 'Stav';
$_['column_points']                               = 'Bonusové body';
$_['column_orders']                               = 'Počet objednávek';
$_['column_total']                                = 'Celkem';
$_['column_action']                               = 'Akce';
$_['entry_date_start']                            = 'Datum - od:';
$_['entry_date_end']                              = 'Datum - do:';
$_['entry_customer']                              = 'Zákazník';
