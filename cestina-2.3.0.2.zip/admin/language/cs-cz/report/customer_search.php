<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Hlášení o hledání zákazníka';
$_['text_list']                                   = 'Seznam vyhledávacích dotazů zákazníka';
$_['text_guest']                                  = 'Návětěvník';
$_['text_customer']                               = '<a href="%s">%s</a>';
$_['column_keyword']                              = 'Klíčové slovo';
$_['column_products']                             = 'Nalezeno produktů';
$_['column_category']                             = 'Kategorie';
$_['column_customer']                             = 'Zákazník';
$_['column_ip']                                   = 'IP';
$_['column_date_added']                           = 'Datum přidání';
$_['entry_date_start']                            = 'Datum od';
$_['entry_date_end']                              = 'Datum do';
$_['entry_keyword']                               = 'Klíčové slovo';
$_['entry_customer']                              = 'Zákazník';
$_['entry_ip']                                    = 'IP';
