<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Hlášení o marketingových kampaních';
$_['text_list']                                   = 'Seznam marketingových kampaní';
$_['text_all_status']                             = 'Všechny stavy';
$_['column_campaign']                             = 'Název kampaně';
$_['column_code']                                 = 'Kód';
$_['column_clicks']                               = 'Počet kliků';
$_['column_orders']                               = 'Počet objednávek';
$_['column_total']                                = 'Celkem';
$_['entry_date_start']                            = 'Datum - od:';
$_['entry_date_end']                              = 'Datum - do:';
$_['entry_status']                                = 'Stav objednávky';
