<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Hlášení o prodaných výrobcích';
$_['text_list']                                   = 'Seznam prodaných výrobků';
$_['text_all_status']                             = 'Všechny stavy';
$_['column_date_start']                           = 'Datum - od:';
$_['column_date_end']                             = 'Datum - do:';
$_['column_name']                                 = 'Název výrobku';
$_['column_model']                                = 'Model';
$_['column_quantity']                             = 'Množství';
$_['column_total']                                = 'Celkem';
$_['entry_date_start']                            = 'Datum - od:';
$_['entry_date_end']                              = 'Datum - do:';
$_['entry_status']                                = 'Stav objednávky';
