<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Hlášení o zobrazených výrobcích';
$_['text_list']                                   = 'Seznam zobrazených výrobků';
$_['text_success']                                = 'Úspěch: Vynuloval jste hlášení o zobrazených produktech!';
$_['column_name']                                 = 'Název produktu';
$_['column_model']                                = 'Model';
$_['column_viewed']                               = 'Zobrazeno';
$_['column_percent']                              = 'Procent';
$_['error_permission']                            = 'Varování: Nemáte oprávnění vynulovat hlášení o zobrazenýc produktech!';
