<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Hlášení o kupónech';
$_['text_list']                                   = 'Seznam kupónů';
$_['column_name']                                 = 'Název kupónů';
$_['column_code']                                 = 'Kód';
$_['column_orders']                               = 'Objednávky';
$_['column_total']                                = 'Celkem';
$_['column_action']                               = 'Akce';
$_['entry_date_start']                            = 'Datum - od:';
$_['entry_date_end']                              = 'Datum - do:';
