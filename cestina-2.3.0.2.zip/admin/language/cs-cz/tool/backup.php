<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Záloha a obnova';
$_['text_success']                                = 'Úspěch: Databáze byla úspěšně importována!';
$_['entry_import']                                = 'Import';
$_['entry_export']                                = 'Export';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat Zálohy!';
$_['error_export']                                = 'Varování: Musíte zvolit minimálně jednu tabulku pro export!';
$_['error_empty']                                 = 'Varování: Nahraný soubor je prázdný!';
