<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Error Log';
$_['text_success']                                = 'Úspěch: Úspěšně jste vyčistili error log!';
$_['text_list']                                   = 'Seznam chyb';
$_['error_warning']                               = 'Varování: Váš error log %s je %s!';
$_['error_permission']                            = 'Varování: Nemáte oprávnění smazat error log!';
