<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Uploady';
$_['text_success']                                = 'Úspěch: Byly upraveny Uploady!';
$_['text_list']                                   = 'Seznam uploadů';
$_['column_name']                                 = 'Název uploadu';
$_['column_filename']                             = 'Název souboru';
$_['column_date_added']                           = 'Datum přidání';
$_['column_action']                               = 'Akce';
$_['entry_name']                                  = 'Název uploadu';
$_['entry_filename']                              = 'Název souboru';
$_['entry_date_added']                            = 'Datum přidání';
$_['error_permission']                            = 'Varování: Nemáte oprávnění upravovat Uploady!';
