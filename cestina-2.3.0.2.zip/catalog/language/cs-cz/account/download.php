<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Stažené objednávky';
$_['text_account']                                = 'Účet';
$_['text_downloads']                              = 'Stažené objednávky';
$_['text_empty']                                  = 'Zatím nemáte staženou žádnou objednávku!';
$_['column_order_id']                             = 'Číslo objednávky';
$_['column_name']                                 = 'Název';
$_['column_size']                                 = 'Velikost';
$_['column_date_added']                           = 'Datum přidání';
