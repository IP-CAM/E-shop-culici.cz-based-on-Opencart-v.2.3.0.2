<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Informace o účtu';
$_['text_account']                                = 'Účet';
$_['text_edit']                                   = 'Upravit informace';
$_['text_your_details']                           = 'Informace o Vaší osobě';
$_['text_success']                                = 'Úspěch: Váš účet byl upraven.';
$_['entry_firstname']                             = 'Jméno';
$_['entry_lastname']                              = 'Příjmení';
$_['entry_email']                                 = 'E-mail';
$_['entry_telephone']                             = 'Telefon';
$_['entry_fax']                                   = 'Fax';
$_['error_exists']                                = 'Varování: Tato e-mailová adresa je již zaregistrována!';
$_['error_firstname']                             = 'Jméno musí mít mezi 1 a 32 znaky!';
$_['error_lastname']                              = 'Příjmení musí mít mezi 1 a 32 znaky!';
$_['error_email']                                 = 'Zdá se, že zadaná e-mailová adresa je neplatná!';
$_['error_telephone']                             = 'Telefon musí mít mezi 3 a 32 znaky!';
$_['error_custom_field']                          = 'Prosím vyplňte pole %s!';
