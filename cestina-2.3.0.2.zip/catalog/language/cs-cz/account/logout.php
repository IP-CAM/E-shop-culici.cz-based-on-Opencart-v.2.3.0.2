<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Odhlášení';
$_['text_message']                                = '<p>Odhlášení proběhlo úspěšně. Nyní můžete bezpečně zavřít okno prohlížeče.</p><p>Obsah Vašeho nákupního košíku byl uložen, jednotlivé položky budou opětovně načtěny do košíku, jakmile se znovu přihlásíte.</p>';
$_['text_account']                                = 'Účet';
$_['text_logout']                                 = 'Odhlášení';
