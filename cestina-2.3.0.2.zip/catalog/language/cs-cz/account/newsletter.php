<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Přihlášení k novinkám';
$_['text_account']                                = 'Účet';
$_['text_newsletter']                             = 'Novinky';
$_['text_success']                                = 'Úspěch: Přihlášení k novinkám bylo provedeno!';
$_['entry_newsletter']                            = 'Přihlásit se';
