<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Vaše bonusové body';
$_['column_date_added']                           = 'Datum přidání';
$_['column_description']                          = 'Popis';
$_['column_points']                               = 'Body';
$_['text_account']                                = 'Účet';
$_['text_reward']                                 = 'Bonusové body';
$_['text_total']                                  = 'Celková výše Vašich bonusových bodů je:';
$_['text_empty']                                  = 'Nemáte žádné bonusové body!';
