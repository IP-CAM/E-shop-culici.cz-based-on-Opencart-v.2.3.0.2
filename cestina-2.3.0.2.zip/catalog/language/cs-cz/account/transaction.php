<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Vaše uzavřené obchody';
$_['column_date_added']                           = 'Datum přidání';
$_['column_description']                          = 'Popis';
$_['column_amount']                               = 'Částka (%s)';
$_['text_account']                                = 'Účet';
$_['text_transaction']                            = 'Vaše uzavřené obchody';
$_['text_total']                                  = 'Váš aktuální stav je:';
$_['text_empty']                                  = 'Nemáte žádné uzavřené obchody!';
