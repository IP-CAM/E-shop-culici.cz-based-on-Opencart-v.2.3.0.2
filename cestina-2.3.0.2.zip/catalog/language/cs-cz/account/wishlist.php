<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Můj seznam přání';
$_['text_account']                                = 'Účet';
$_['text_instock']                                = 'Množství';
$_['text_wishlist']                               = 'Seznam přání (%s)';
$_['text_login']                                  = 'Musíte se <a href="%s">přihlásit</a> nebo <a href="%s">vytvořit účet</a> k uložení <a href="%s">%s</a> do Vašeho <a href="%s">seznamu přání</a>!';
$_['text_success']                                = 'Úspěch: Přidal(a) jste <a href="%s">%s</a> do Vašeho <a href="%s">seznamu přání</a>!';
$_['text_remove']                                 = 'Úspěch: Upravil(a) jste Váš seznam přání!';
$_['text_empty']                                  = 'Váš seznam přání je prázdný.';
$_['column_image']                                = 'Obrázek';
$_['column_name']                                 = 'Název výrobku';
$_['column_model']                                = 'Model';
$_['column_stock']                                = 'Množství';
$_['column_price']                                = 'Cena za jednotku';
$_['column_action']                               = 'Akce';
