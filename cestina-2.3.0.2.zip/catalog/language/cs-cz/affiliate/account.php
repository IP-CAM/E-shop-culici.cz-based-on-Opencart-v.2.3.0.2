<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Můj účet obchodního partnera';
$_['text_account']                                = 'Účet';
$_['text_my_account']                             = 'Můj účet obchodního partnera';
$_['text_my_tracking']                            = 'Moje údaje pro sledování';
$_['text_my_transactions']                        = 'Uzavřené obchody';
$_['text_edit']                                   = 'Upravit informace o účtu';
$_['text_password']                               = 'Změnit heslo';
$_['text_payment']                                = 'Změnit způsob platby';
$_['text_tracking']                               = 'Vlastní sledovací kód partnera';
$_['text_transaction']                            = 'Zobrazit historii uzavřených obchodů';
