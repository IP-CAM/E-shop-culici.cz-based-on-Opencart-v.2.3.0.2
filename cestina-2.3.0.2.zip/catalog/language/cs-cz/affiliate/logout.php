<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Odhlášení z účtu';
$_['text_message']                                = '<p>Byl jste odhlášen z účtu obchodního partnera.</p>';
$_['text_account']                                = 'Účet';
$_['text_logout']                                 = 'Odhlášení';
