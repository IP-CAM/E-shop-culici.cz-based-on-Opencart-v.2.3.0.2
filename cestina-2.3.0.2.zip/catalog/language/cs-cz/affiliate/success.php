<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Váš účet obchodního partnera byl vytvořen!';
$_['text_message']                                = '<p>Gratulujeme! Váš účet byl úspěšně vytvořen!</p><p>Nyní můžete využívat všech výhod členství, které ještě více zlepší online nakupování v našem obchodě.</p> <p>V případě jakýchkoliv dotazů ohledně fungování tohoto e-shopu, kontaktujte administrátora obchodu.</p> <p>Na Vaši e-mailovou adresu bylo zasláno potvrzení o registraci. Pokud jej do hodiny neobdržíte, prosím <a href="%s">kontaktujte nás</a>.</p>';
$_['text_approval']                               = '<p>Děkujeme za registraci účtu obchodního partnera v %s!</p><p>Až bude Váš účet aktivován, budete o tom informován(a) administrátorem obchodu prostřednictvím Vašeho e-mailu.</p><p>V případě jakýchkoliv dotazů ohledně fungování tohoto partnerského programu, prosím <a href="%s">kontaktujte administrátora obchodu</a>.</p>';
$_['text_account']                                = 'Účet';
$_['text_success']                                = 'Úspěch';
