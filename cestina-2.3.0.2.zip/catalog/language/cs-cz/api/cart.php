<?php //Copyright: opencart.cz
$_['text_success']                                = 'Úspěch: Upravil(a) jste svůj nákupní košík!';
$_['error_permission']                            = 'Varování: Nemáte oprávnění k přístupu do API!';
$_['error_stock']                                 = 'Výrobky označené *** nejsou dostupné v požadovaném množství nebo nejsou na skladě!';
$_['error_minimum']                               = 'Minimální množství pro %s, které lze objednat je: %s!';
$_['error_store']                                 = 'Výrobek nemůže být zakoupen v obchodě, který jste si vybral(a)!';
$_['error_required']                              = 'Prosím vyplňte pole %s!';
