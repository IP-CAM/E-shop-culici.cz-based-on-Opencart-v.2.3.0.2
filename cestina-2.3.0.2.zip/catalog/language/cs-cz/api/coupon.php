<?php //Copyright: opencart.cz
$_['text_success']                                = 'Úspěch: Váš slevový kupón byl použit!';
$_['error_permission']                            = 'Varování: Nemáte oprávnění k přístupu do API';
$_['error_coupon']                                = 'Varování: Kupón již není platný, vypršel, nebo bylo dosaženo maximálního počtu použití kupónu!';
