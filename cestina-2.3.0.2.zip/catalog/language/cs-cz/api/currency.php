<?php //Copyright: opencart.cz
$_['text_success']                                = 'Úspěch: Měna byla změněna!';
$_['error_permission']                            = 'Varování: Nemáte oprávnění přístupu k API!';
$_['error_currency']                              = 'Varování: Kód měny je chybný!';
