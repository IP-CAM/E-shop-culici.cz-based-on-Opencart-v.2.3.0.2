<?php //Copyright: opencart.cz
$_['text_success']                                = 'Úspěšně jste upravil(a) zákazníky';
$_['error_permission']                            = 'Varování: Nemáte oprávnění k přístupu do API';
$_['error_firstname']                             = 'Jméno musí mít mezi 1 a 32 znaky!';
$_['error_lastname']                              = 'Příjmení musí mít mezi 1 a 32 znaky!';
$_['error_email']                                 = 'E-mailová adresa je zřejmě neplatná!';
$_['error_telephone']                             = 'Telefon musí mít mezi 3 a 32 znaky!';
$_['error_custom_field']                          = 'Prosím vyplňte pole %s!';
