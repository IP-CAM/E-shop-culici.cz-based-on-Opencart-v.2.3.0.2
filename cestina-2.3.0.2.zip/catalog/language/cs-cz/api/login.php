<?php //Copyright: opencart.cz
$_['text_success']                                = 'Úspěch: Relace API byla spuštěna!';
$_['error_key']                                   = 'Varování: Nesprávný API klíč!';
$_['error_ip']                                    = 'Varování: Z Vaší IP adresy %s není povoleno přistupovat k této API!';
