<?php //Copyright: opencart.cz
$_['text_success']                                = 'You order has been successfully modified orders';
$_['error_permission']                            = 'Varování: Nemáte oprávnění k přístupu do API';
$_['error_customer']                              = 'Musíte nastavit podrobnosti o zákazníkovi!';
$_['error_payment_address']                       = 'Požadována fakturační adresa!';
$_['error_payment_method']                        = 'Požadován způsob platby!';
$_['error_no_payment']                            = 'Varování: Nejsou dostupné možnosti platby!';
$_['error_shipping_address']                      = 'Požadována adresa dodání!';
$_['error_shipping_method']                       = 'Požadován zpúsob dopravy!';
$_['error_no_shipping']                           = 'Varování: Nejsou dostupné možnosti dopravy!';
$_['error_stock']                                 = 'Výrobky označené *** nejsou dostupné v požadovaném množství nebo nejsou na skladě!';
$_['error_minimum']                               = 'Minimální množství pro %s, které lze objednat je: %s!';
$_['error_not_found']                             = 'Varování: Objednávka nebyla nalezena!';
