<?php //Copyright: opencart.cz
$_['text_address']                                = 'Úspěch: Fakturační adresa byla nastavena!';
$_['text_method']                                 = 'Úspěch: Způsob platby byl nastaven!';
$_['error_permission']                            = 'Varování: Nemáte oprávnění k přístupu do API';
$_['error_firstname']                             = 'Jméno musí mít mezi 1 a 32 znaky!';
$_['error_lastname']                              = 'Příjmení musí mít mezi 1 a 32 znaky!';
$_['error_address_1']                             = 'Address 1 musí mít mezi 3 a 128 znaky!';
$_['error_city']                                  = 'Město musí mít mezi 3 a 128 znaky!';
$_['error_postcode']                              = 'PSČ v této zemi musí mít mezi 2 a 10 znaky!';
$_['error_country']                               = 'Prosím vyberte zemi';
$_['error_zone']                                  = 'Prosím vyberte kraj';
$_['error_custom_field']                          = 'Prosím vyplňte pole %s!';
$_['error_address']                               = 'Varování: Požadována fakturační adresa!';
$_['error_method']                                = 'Varování: Požadován způsob platby!';
$_['error_no_payment']                            = 'Varování: Nejsou k dospozici žádné možnosti platby!';
