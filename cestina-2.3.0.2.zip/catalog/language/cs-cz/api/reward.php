<?php //Copyright: opencart.cz
$_['text_success']                                = 'Úspěch: Vaše bonusové body byly použity!';
$_['error_permission']                            = 'Varování: Nemáte oprávnění k přístupu do API';
$_['error_reward']                                = 'Varování: Prosím vložte počet bodů, který chcete použít!';
$_['error_points']                                = 'Varování: Nemáte %s bonusových bodů!';
$_['error_maximum']                               = 'Varování: Maximální počet bodů, který může být použit je %s!';
