<?php //Copyright: opencart.cz
$_['text_success']                                = 'Úspěch: Váš dárkový poukaz byl použit!';
$_['text_cart']                                   = 'Úspěch: Upravil(a) jste svůj nákupní košík!';
$_['text_for']                                    = '%s dárkový poukaz pro %s';
$_['error_permission']                            = 'Varování: Nemáte oprávnění k přístupu do API';
$_['error_voucher']                               = 'Varování: Dárkový poukaz je již neplatný nebo byl použit!';
$_['error_to_name']                               = 'Jméno příjemce musí mít mezi 1 a 64 znaky!';
$_['error_from_name']                             = 'Vače jméno musí mít mezi 1 a 64 znaky!';
$_['error_email']                                 = 'E-mailová adresa je zřejmě neplatná!';
$_['error_theme']                                 = 'Musíte vybrat motiv!';
$_['error_amount']                                = 'Částka musí mít mezi %s a %s!';
