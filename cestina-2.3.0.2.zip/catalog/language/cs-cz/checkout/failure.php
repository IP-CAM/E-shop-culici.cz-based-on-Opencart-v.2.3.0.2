<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Chyba při platbě!';
$_['text_basket']                                 = 'Nákupní košík';
$_['text_checkout']                               = 'Objednat';
$_['text_failure']                                = 'Chyba při platbě';
$_['text_message']                                = '<p>Při platbě nastal problém, objednávka nebyla dokončena.</p>

<p>Možnými důvody jsou:</p>
<ul>
  <li>Nedostatek peněžních prostředků</li>
  <li>Selhání ověření platby</li>
</ul>

<p>Prosím proveďte objednávku znovu a vyberte jiný způsob platby.</p>

<p>Pokud problémy přetrvávají prosím <a href="%s">kontaktujte nás</a> a sdělte nám podrobnosti o objednávce, kterou chcete uskutečnit.</p>
';
