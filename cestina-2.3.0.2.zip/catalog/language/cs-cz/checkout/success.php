<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Vaše objednávka byla odeslána ke zpracování!';
$_['text_basket']                                 = 'Nákupní košík';
$_['text_checkout']                               = 'Objednat';
$_['text_success']                                = 'Dokončeno';
$_['text_customer']                               = '<p>Vaše objednávka byla úspěšně odeslána ke zpracování!</p><p>Můžete zobrazit historii Vašich objednávek na <a href="%s">"Můj účet"</a> a kliknout na <a href="%s">"Historie objednávek"</a>.</p><p>Pokud je Vaše objednávka propojena se stahováním, jděte na <a href="%s">"Stažené objednávky"</a> a zobrazte si její položky.</p><p>Jakékoliv dotazy prosím směřujte na <a href="%s">administrátora obchodu</a>.</p><p>Děkujeme  za využití našich služeb!</p>';
$_['text_guest']                                  = '<p>Vaše objednávka byla úspěšně odeslána ke zpracování!</p><p>Jakékoliv dotazy prosím směřujte na <a href="%s">administrátora obchodu</a>.</p><p>Děkujeme  za využití našich služeb!</p>';
