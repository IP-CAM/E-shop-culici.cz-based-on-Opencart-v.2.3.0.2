<?php //Copyright: opencart.cz
$_['text_items']                                  = '%s položek - %s';
$_['text_empty']                                  = 'Váš nákupní košík je prázdný!';
$_['text_cart']                                   = 'Zobrazit obsah košíku';
$_['text_checkout']                               = 'Objednat';
$_['text_recurring']                              = 'Profil platby';
