<?php //Copyright: opencart.cz
$_['text_currency']                               = 'Měna';
