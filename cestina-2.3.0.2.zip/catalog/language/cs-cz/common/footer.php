<?php //Copyright: opencart.cz
$_['text_information']                            = 'Informace';
$_['text_service']                                = 'Zákaznický servis';
$_['text_extra']                                  = 'Doplňky';
$_['text_contact']                                = 'Napište nám';
$_['text_return']                                 = 'Reklamace';
$_['text_sitemap']                                = 'Mapa stránek';
$_['text_manufacturer']                           = 'Výrobci';
$_['text_voucher']                                = 'Dárkové poukazy';
$_['text_affiliate']                              = 'Partnerský program';
$_['text_special']                                = 'Lepší nabídky';
$_['text_account']                                = 'Můj účet';
$_['text_order']                                  = 'Historie objednávek';
$_['text_wishlist']                               = 'Seznam přání';
$_['text_newsletter']                             = 'Novinky';
$_['text_powered']                                = 'Systém <a href="http://www.opencart.com">OpenCart</a><br /> %s &copy; %s<br />Překlad: <a href="http://www.opencart.cz" target="_blank">opencart.cz</a> &amp; <a href="http://www.opencart-support.com" target="_blank">opencart-support.com</a>.';
