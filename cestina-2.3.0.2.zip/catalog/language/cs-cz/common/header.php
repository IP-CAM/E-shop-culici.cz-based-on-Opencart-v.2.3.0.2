<?php //Copyright: opencart.cz
$_['text_home']                                   = 'Domů';
$_['text_wishlist']                               = 'Seznam přání (%s)';
$_['text_shopping_cart']                          = 'Nákupní košík';
$_['text_category']                               = 'Kategorie';
$_['text_account']                                = 'Můj účet';
$_['text_register']                               = 'Zaregistrovat se';
$_['text_login']                                  = 'Přihlásit se';
$_['text_order']                                  = 'Historie objednávek';
$_['text_transaction']                            = 'Uzavřené obchody';
$_['text_download']                               = 'Stažené objednávky';
$_['text_logout']                                 = 'Odhlásit se';
$_['text_checkout']                               = 'Objednat';
$_['text_search']                                 = 'Vyhledat';
$_['text_all']                                    = 'Zobrazit vše';
