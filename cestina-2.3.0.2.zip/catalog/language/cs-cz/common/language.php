<?php //Copyright: opencart.cz
$_['text_language']                               = 'Jazyk';
