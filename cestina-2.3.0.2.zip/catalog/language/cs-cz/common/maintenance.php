<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Údržba';
$_['text_maintenance']                            = 'Údržba';
$_['text_message']                                = '<h1 style="text-align:center;">Omlouváme se, na stránkách je právě prováděna údržba.</h1>';
