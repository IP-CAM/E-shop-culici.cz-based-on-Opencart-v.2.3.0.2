<?php //Copyright: opencart.cz
$_['text_search']                                 = 'Vyhledat';
