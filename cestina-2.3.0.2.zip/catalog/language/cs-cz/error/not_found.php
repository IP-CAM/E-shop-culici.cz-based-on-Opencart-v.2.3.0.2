<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Stránka nenalezena!!';
$_['text_error']                                  = 'Stránka, kterou hledáte, nebyla nalezena!';
