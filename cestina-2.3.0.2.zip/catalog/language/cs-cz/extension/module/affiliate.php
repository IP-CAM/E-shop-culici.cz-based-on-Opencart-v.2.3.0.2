<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Obchodní partner';
$_['text_register']                               = 'Registrace';
$_['text_login']                                  = 'Přihlášení';
$_['text_logout']                                 = 'Odhlášení';
$_['text_forgotten']                              = 'Zapomenuté heslo';
$_['text_account']                                = 'Můj účet';
$_['text_edit']                                   = 'Upravit účet';
$_['text_password']                               = 'Heslo';
$_['text_payment']                                = 'Možnosti platby';
$_['text_tracking']                               = 'Sledování obchodního partnera';
$_['text_transaction']                            = 'Uzavřené obchody';
