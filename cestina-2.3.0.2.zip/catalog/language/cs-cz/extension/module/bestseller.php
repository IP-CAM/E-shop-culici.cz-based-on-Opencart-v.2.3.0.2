<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Nejlvíce prodávané';
$_['text_tax']                                    = 'Cena bez DPH:';
