<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Kategorie';
