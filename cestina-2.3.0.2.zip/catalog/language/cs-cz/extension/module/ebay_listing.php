<?php //Copyright: opencart.cz
$_['heading_title']                               = 'On our eBay store';
