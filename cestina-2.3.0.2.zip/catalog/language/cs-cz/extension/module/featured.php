<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Doporučené produkty';
$_['text_tax']                                    = 'Cena bez DPH:';
