<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Rozšířené hledání';
