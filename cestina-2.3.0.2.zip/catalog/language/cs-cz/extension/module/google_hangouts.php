<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Live Chat';
