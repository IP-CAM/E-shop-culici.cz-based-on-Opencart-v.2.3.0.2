<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Informace';
$_['text_contact']                                = 'Kontaktujte nás';
$_['text_sitemap']                                = 'Mapa stránek';
