<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Nejnovější';
$_['text_tax']                                    = 'Cena bez DPH:';
