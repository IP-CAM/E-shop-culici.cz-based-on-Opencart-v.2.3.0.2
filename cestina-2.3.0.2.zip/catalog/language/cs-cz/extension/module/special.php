<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Lepší nabídky';
$_['text_tax']                                    = 'Cena bez DPH:';
