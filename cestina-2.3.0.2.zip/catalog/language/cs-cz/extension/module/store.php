<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Vyberte obchod';
$_['text_default']                                = 'Výchozí';
$_['text_store']                                  = 'Prosím vyberte obchod, který chcete navštívit.';
