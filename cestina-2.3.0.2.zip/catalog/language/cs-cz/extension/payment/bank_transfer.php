<?php //Copyright: opencart.cz
$_['text_title']                                  = 'Bankovní převod';
$_['text_instruction']                            = 'Pokyny k bankovnímu převodu';
$_['text_description']                            = 'Prosím převěďte tuto částku na následující bankovní účet.';
$_['text_payment']                                = 'Vaše objednávka nebude vyřízena, dokud neobdržíme platbu.';
