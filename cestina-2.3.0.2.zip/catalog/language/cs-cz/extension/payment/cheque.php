<?php //Copyright: opencart.cz
$_['text_title']                                  = 'Šek';
$_['text_instruction']                            = 'Šek - instrukce';
$_['text_payable']                                = 'Splatné (komu): ';
$_['text_address']                                = 'Odeslat na: ';
$_['text_payment']                                = 'Vaše objednávka nebude vyřízena, dokud neobdržíme platbu';
