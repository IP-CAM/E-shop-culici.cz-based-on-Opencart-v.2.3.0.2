<?php //Copyright: opencart.cz
$_['text_title']                                  = 'Pilibaba (霹雳爸爸支付)';
$_['text_redirecting']                            = 'Redirecting...';
