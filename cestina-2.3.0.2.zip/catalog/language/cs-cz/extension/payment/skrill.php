<?php //Copyright: opencart.cz
$_['text_title']                                  = 'Credit Card / Debit Card (Skrill)';
