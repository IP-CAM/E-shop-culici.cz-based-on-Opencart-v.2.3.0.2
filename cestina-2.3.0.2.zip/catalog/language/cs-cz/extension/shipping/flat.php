<?php //Copyright: opencart.cz
$_['text_title']                                  = 'Jednotná sazba dopravy';
$_['text_description']                            = 'Jednotná sazba dopravy';
