<?php //Copyright: opencart.cz
$_['text_title']                                  = 'Za kus';
$_['text_description']                            = 'Doprava hodnocená podle počtu kusů';
