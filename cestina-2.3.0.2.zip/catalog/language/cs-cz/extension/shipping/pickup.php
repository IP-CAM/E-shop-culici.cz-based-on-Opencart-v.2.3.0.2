<?php //Copyright: opencart.cz
$_['text_title']                                  = 'Vyzvednutí';
$_['text_description']                            = 'Vyzvednutí v obchodě';
