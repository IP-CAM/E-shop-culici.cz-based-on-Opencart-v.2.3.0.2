<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Použít kód slevového kuponu';
$_['text_coupon']                                 = 'Kupon (%s)';
$_['text_success']                                = 'Úspěch: Slevový kupon byl využit!';
$_['entry_coupon']                                = 'Sem vložte kód kuponu';
$_['error_coupon']                                = 'Varování: Kupon je buď chybný, vypršel, nebo byl dosažen maximální počet jeho použítí!';
$_['error_empty']                                 = 'Varování: Vložte kód kuponu!';
