<?php //Copyright: opencart.cz
$_['text_credit']                                 = 'Kredit obchodu';
$_['text_order_id']                               = 'Číslo objednávky: #%s';
