<?php //Copyright: opencart.cz
$_['text_handling']                               = 'Manipulační poplatek';
