<?php //Copyright: opencart.cz
$_['text_klarna_fee']                             = 'Klarna Fee';
