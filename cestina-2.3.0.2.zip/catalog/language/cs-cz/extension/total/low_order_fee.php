<?php //Copyright: opencart.cz
$_['text_low_order_fee']                          = 'Poplatek za malý počet položek na objednávce';
