<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Použití bonusových bodů (Dostupných bodů: %s)';
$_['text_reward']                                 = 'Bonusové body (%s)';
$_['text_order_id']                               = 'Číslo objednávky: #%s';
$_['text_success']                                = 'Úspěch: Bonusové body byly využity!';
$_['entry_reward']                                = 'Body k použití (Maximum %s)';
$_['error_reward']                                = 'Varování: Vložte počet bonusových bodů, které chcete využít!';
$_['error_points']                                = 'Varování: Nemáte %s bonusových bodů!';
$_['error_maximum']                               = 'Varování: Maximální počet bodů, který může být využit je %s!';
