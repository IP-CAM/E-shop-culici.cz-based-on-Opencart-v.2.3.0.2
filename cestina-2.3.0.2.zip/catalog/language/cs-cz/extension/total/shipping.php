<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Odhad výše dopravy';
$_['text_success']                                = 'Úspěch: Výše dopravy byla použita!';
$_['text_shipping']                               = 'Vložte prosím Vaše umístění, aby mohla být provedena kalkulace výše dopravy!';
$_['text_shipping_method']                        = 'Prosím vyberte požadovaný způsob dopravy.';
$_['entry_country']                               = 'Země';
$_['entry_zone']                                  = 'Kraj';
$_['entry_postcode']                              = 'PSČ';
$_['error_postcode']                              = 'PSČ musí mít mezi 2 a 10 znaky!';
$_['error_country']                               = 'Prosím vyberte zemi';
$_['error_zone']                                  = 'Prosím vyberte kraj';
$_['error_shipping']                              = 'Varování: Požadován způsob dopravy!';
$_['error_no_shipping']                           = 'Varování: Není k dispozici způsob dopravy. Prosím <a href="%s">kontaktujte nás</a>!';
