<?php //Copyright: opencart.cz
$_['text_sub_total']                              = 'Cena bez DPH';
