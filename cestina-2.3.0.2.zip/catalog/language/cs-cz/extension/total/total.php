<?php //Copyright: opencart.cz
$_['text_total']                                  = 'Celkem s DPH';
