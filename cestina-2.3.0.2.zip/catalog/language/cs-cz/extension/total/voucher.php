<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Použití dárkového poukazu';
$_['text_voucher']                                = 'Dárkový poukaz (%s)';
$_['text_success']                                = 'Úspěch: Váš dárkový poukaz byl použit!';
$_['entry_voucher']                               = 'Vložte sem prosím kód dárkového poukazu';
$_['error_voucher']                               = 'Varování: Dárkový poukaz je již neplatný nebo byl použit!';
$_['error_empty']                                 = 'Varování: Prosím vložte kód dárkového poukazu!';
