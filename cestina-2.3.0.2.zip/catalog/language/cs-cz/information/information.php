<?php //Copyright: opencart.cz
$_['text_error']                                  = 'Stránka Informace nebyla nalezena!';
