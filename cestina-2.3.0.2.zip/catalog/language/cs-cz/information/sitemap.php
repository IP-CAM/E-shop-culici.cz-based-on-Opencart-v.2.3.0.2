<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Mapa stránek';
$_['text_special']                                = 'Lepší nabídky';
$_['text_account']                                = 'Můj účet';
$_['text_edit']                                   = 'Informace o účtu';
$_['text_password']                               = 'Heslo';
$_['text_address']                                = 'Vaše adresy';
$_['text_history']                                = 'Historie objednávek';
$_['text_download']                               = 'Stažené objednávky';
$_['text_cart']                                   = 'Nákupní košík';
$_['text_checkout']                               = 'Objednat';
$_['text_search']                                 = 'Hledat';
$_['text_information']                            = 'Informace';
$_['text_contact']                                = 'Kontaktujte nás';
