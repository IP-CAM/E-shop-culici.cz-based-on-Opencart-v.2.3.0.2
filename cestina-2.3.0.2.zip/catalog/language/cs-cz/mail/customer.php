<?php //Copyright: opencart.cz
$_['text_subject']                                = '%s - Děkujeme za registraci';
$_['text_welcome']                                = 'Vítejte a děkujeme za registraci v %s!';
$_['text_login']                                  = 'Váš účet byl vytvořen, můžete se přihlásit pomocí vaší emailové adresy a zaregistrovaného hesla nebo na následující internetové adrese:';
$_['text_approval']                               = 'Váš účet musí být před přihlášením ověřen. Po ověření se můžete se přihlásit pomocí vaší emailové adresy a zaregistrovaného hesla nebo na následující internetové adrese: ';
$_['text_services']                               = 'Po přihlášení máte přístup k dalším službám, jako například prohlížet dřívější objednávky, tisk faktur a měnit informace o Vašem účtu.';
$_['text_thanks']                                 = 'Děkujeme,';
$_['text_new_customer']                           = 'Nový zákazník';
$_['text_signup']                                 = 'Přihlásil se nový zákazník:';
$_['text_website']                                = 'Web:';
$_['text_customer_group']                         = 'Skupina zákazníků:';
$_['text_firstname']                              = 'Jméno:';
$_['text_lastname']                               = 'Příjmení:';
$_['text_email']                                  = 'E-mail:';
$_['text_telephone']                              = 'Telefon:';
