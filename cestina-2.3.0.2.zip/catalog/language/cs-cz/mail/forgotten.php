<?php //Copyright: opencart.cz
$_['text_subject']                                = '%s - Nové heslo';
$_['text_greeting']                               = 'Nové heslo je požadováno od %s.';
$_['text_change']                                 = 'To reset your password click on the link below:';
$_['text_ip']                                     = 'The IP used to make this request was: %s';
