<?php //Copyright: opencart.cz
$_['text_subject']                                = '%s - Recenze výrobku';
$_['text_waiting']                                = 'Máte recenzi ke schválení.';
$_['text_product']                                = 'Výrobek: %s';
$_['text_reviewer']                               = 'Recenze: %s';
$_['text_rating']                                 = 'Hodnocení: %s';
$_['text_review']                                 = 'Text recenze:';
