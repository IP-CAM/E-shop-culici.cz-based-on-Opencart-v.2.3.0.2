<?php //Copyright: opencart.cz
$_['text_subject']                                = 'Přišel Vám dárkový poukaz od %s';
$_['text_greeting']                               = 'Gratulujeme, obdržel(a) jste dárkový poukaz v hodnotě %s';
$_['text_from']                                   = 'Tento poukaz Vám poslal %s';
$_['text_message']                                = 'Se zprávou';
$_['text_redeem']                                 = 'Pro vyzvednutí poukazu si poznamenejte tento kód: <b>%s</b>. Pak klikněte na odkaz níže a nakupte zboží na které chce poukaz použít. Zadejte kód poukazu na stránce košíku před tím než objednávku odešlete.';
$_['text_footer']                                 = 'V případě dotazů, prosím odpovězte na tento e-mail.';
