<?php //Copyright: opencart.cz
$_['heading_title']                               = 'Porovnání výrobků';
$_['text_product']                                = 'Podrobnosti o výrobku';
$_['text_name']                                   = 'Výrobek';
$_['text_image']                                  = 'Obrázek';
$_['text_price']                                  = 'Cena';
$_['text_model']                                  = 'Model';
$_['text_manufacturer']                           = 'Výrobce';
$_['text_availability']                           = 'Dostupnost';
$_['text_instock']                                = 'Na skladě';
$_['text_rating']                                 = 'Hodnocení';
$_['text_reviews']                                = 'Založeno na %s recenzích.';
$_['text_summary']                                = 'Shrnutí';
$_['text_weight']                                 = 'Hmotnost';
$_['text_dimension']                              = 'Rozměry (d x š x v)';
$_['text_compare']                                = 'Porovnání výrobku (%s)';
$_['text_success']                                = 'Úspěch: Přidal(a) jste <a href="%s">%s</a> do Vašeho <a href="%s">porovnání produktů</a>!';
$_['text_remove']                                 = 'Úspěch: Upravil(a) jste porovnání produktů!';
$_['text_empty']                                  = 'Nevybral(a) jste žádné produkty k porovnání.';
