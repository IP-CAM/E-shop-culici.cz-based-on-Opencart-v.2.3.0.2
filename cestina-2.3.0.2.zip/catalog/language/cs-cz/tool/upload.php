<?php //Copyright: opencart.cz
$_['text_upload']                                 = 'Váš soubor byl úspěšně nahrán!';
$_['error_filename']                              = 'Název souboru musí mít mezi 3 a 64 znaky!';
$_['error_filetype']                              = 'Chybný typ souboru!';
$_['error_upload']                                = 'Požadován upload!';
